function sayHello() {
  alert("홈 페이지 JS 작동!");
}
console.log("✅ home.js loaded");